<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Assignment 4</title>
		<link rel="stylesheet" href="blog.css" type="text/css"/>
		<link rel="stylesheet" href="../stylesheet.css" type="text/css"/>
	</head>
	<?php
		include '../menu.inc';
	?> 
	<body> 
        <div id="maincontent">
        <div class="blogBack">
		<div class="register">
			<div><a href="http://helios.ite.gmu.edu/~azaheer/IT207/Assignment4/indexT.php">Text Version</a></div>
		</div>
		<div class="register">
			<div><a href="http://helios.ite.gmu.edu/~azaheer/IT207/Assignment4/indexD.php">Database Version</a></div>
		</div>
        </div>
        </div>
    </body>
</html>